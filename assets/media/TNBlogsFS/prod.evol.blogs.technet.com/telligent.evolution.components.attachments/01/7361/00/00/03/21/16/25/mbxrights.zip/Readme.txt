1. Copy Adssecurity.dll to windows\system32 on a machine running ESM, if this does not work, try an Exchange Server.
2. Regsvr32 adssecurity.dll from the windows\system32 directory.
3. You have three options: domain, container, or user.

Syntax from a command line. This lists full mailbox access.

Domain:

mailbox_rights.vbs /con:contoso.com /o:c:\tools\auditall.txt

Container or OU:

mailbox_rights.vbs /con:ou=home,dc=contoso,dc=com /o:c:\tools\audithome.txt

User:
mailbox_rights.vbs /dn:cn=lou,ou=home,dc=contoso,dc=com /o:c:\tools\audituser.txt
 
4. You can also add /send to list who has send access.
 